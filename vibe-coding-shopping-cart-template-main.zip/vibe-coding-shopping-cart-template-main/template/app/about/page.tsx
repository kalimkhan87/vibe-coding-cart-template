export default function About(){ return (<div className="max-w-4xl mx-auto px-4 py-8"><h1 className="text-2xl font-bold">About ShopWave</h1></div>)}
