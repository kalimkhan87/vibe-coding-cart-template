export default function Login(){ return (<div className="max-w-md mx-auto px-4 py-8"><h1 className="text-2xl font-bold">Login</h1></div>)}
