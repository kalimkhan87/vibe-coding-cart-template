import Link from 'next/link';
import HomeL1 from './home/layout1/page';
export default function IndexPage(){
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <HomeL1 />
     
      
    </div>
  );
}
